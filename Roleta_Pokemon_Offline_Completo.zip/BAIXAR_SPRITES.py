#!/usr/bin/env python3
"""Baixa PNGs reais do Pokémon Showdown usando apenas Python 3 padrão."""
import json, pathlib, urllib.request, urllib.error, time, struct, zipfile
base=pathlib.Path(__file__).resolve().parent
names=json.loads((base/'lista_sprites.json').read_text(encoding='utf-8'))
out=base/'sprites'/'trainers';out.mkdir(parents=True, exist_ok=True)
roots=['https://play.pokemonshowdown.com/sprites/trainers/','https://pokemonshowdown.com/sprites/trainers/']
failed=[];downloaded=0;previous=0
for i,name in enumerate(names,1):
 target=out/name
 if target.exists() and target.read_bytes()[:8]==b'\x89PNG\r\n\x1a\n':previous+=1;continue
 ok=False
 for root in roots:
  try:
   req=urllib.request.Request(root+name,headers={'User-Agent':'Mozilla/5.0'})
   with urllib.request.urlopen(req,timeout=15) as response:data=response.read()
   if data[:8]!=b'\x89PNG\r\n\x1a\n':raise ValueError('Resposta não é PNG')
   target.write_bytes(data);downloaded+=1;ok=True;break
  except Exception as exc:
   err=str(exc)
 if not ok:failed.append((name,err))
 print(f'[{i}/{len(names)}] {name}: '+('OK' if ok else 'FALHOU'))
(base/'FALTANDO.txt').write_text('\n'.join(f'{n}: {e}' for n,e in failed),encoding='utf-8')
with zipfile.ZipFile(base/'Sprites_Treinadores_Baixados.zip','w',zipfile.ZIP_DEFLATED) as z:
 for file in sorted(out.glob('*.png')):z.write(file,'sprites/trainers/'+file.name)
print(f'\nBaixados: {downloaded}; já existentes: {previous}; faltando: {len(failed)}')
print('ZIP:',base/'Sprites_Treinadores_Baixados.zip')
if failed: print('Veja FALTANDO.txt. Se a sua rede bloquear ambos os domínios, use outra rede autorizada.')
input('Pressione Enter para sair...')
