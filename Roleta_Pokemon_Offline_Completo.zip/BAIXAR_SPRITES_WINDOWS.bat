@echo off
cd /d "%~dp0"
py -3 BAIXAR_SPRITES.py
if errorlevel 1 python BAIXAR_SPRITES.py
pause
